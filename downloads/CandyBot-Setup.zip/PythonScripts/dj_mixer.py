#!/usr/bin/env python3
"""
Candy-Bot DJ Engine — Automated Mixer
Takes a sequenced playlist (JSON) and creates a continuous mix.
Handles beat-aligned crossfades, time stretching, and volume automation.

Usage:
    python dj_mixer.py <playlist.json> <output.mp3> [--style crossfade|drop_swap]
"""

import sys
import os
import json
import warnings
import numpy as np

warnings.filterwarnings("ignore")

import librosa
import soundfile as sf
from pydub import AudioSegment


def time_stretch_audio(audio_segment, original_bpm, target_bpm):
    """Time-stretch an audio segment to match target BPM."""
    if abs(original_bpm - target_bpm) < 0.5:
        return audio_segment  # Close enough, skip stretching

    ratio = target_bpm / original_bpm

    # Export to raw, stretch with librosa, reimport
    samples = np.array(audio_segment.get_array_of_samples(), dtype=np.float32)
    samples = samples / (2**15)  # Normalize to [-1, 1]

    # Handle stereo
    channels = audio_segment.channels
    if channels == 2:
        samples = samples.reshape((-1, 2))
        left = librosa.effects.time_stretch(samples[:, 0], rate=ratio)
        right = librosa.effects.time_stretch(samples[:, 1], rate=ratio)
        stretched = np.column_stack([left, right]).flatten()
    else:
        stretched = librosa.effects.time_stretch(samples, rate=ratio)

    # Convert back to int16
    stretched = np.clip(stretched * (2**15), -32768, 32767).astype(np.int16)

    return AudioSegment(
        data=stretched.tobytes(),
        sample_width=2,
        frame_rate=audio_segment.frame_rate,
        channels=channels
    )


def find_mix_point(track_data, position="outro"):
    """Find the best mix-in or mix-out point in seconds."""
    structure = track_data.get("structure", {})
    if position == "outro":
        return structure.get("outro_start_sec", structure.get("duration_sec", 180) - 32)
    else:  # intro
        return structure.get("intro_end_sec", 16)


def crossfade_mix(track_a_seg, track_b_seg, crossfade_ms=16000):
    """Standard crossfade between two tracks."""
    # Ensure crossfade doesn't exceed either track
    max_fade = min(len(track_a_seg) // 2, len(track_b_seg) // 2, crossfade_ms)
    return track_a_seg.append(track_b_seg, crossfade=max_fade)


def drop_swap_mix(track_a_seg, track_b_seg, track_b_data):
    """Cut from track A's energy into track B's drop."""
    peak_ms = int(track_b_data.get("structure", {}).get("peak_time_sec", 30) * 1000)

    # Take everything before the peak of track B as the "intro"
    intro_b = track_b_seg[:peak_ms]
    drop_b = track_b_seg[peak_ms:]

    # Fade out last 4 bars of track A (~8 seconds at 128 BPM)
    fade_out_ms = 8000
    track_a_ending = track_a_seg[-fade_out_ms:].fade_out(fade_out_ms)
    track_a_body = track_a_seg[:-fade_out_ms]

    # Build: Track A body → quick fade → Track B from drop
    result = track_a_body + track_a_ending
    result = result.append(drop_b, crossfade=2000)

    return result


def create_mix(playlist_data, output_path, style="crossfade"):
    """Create a continuous mix from a sequenced playlist."""
    tracks = playlist_data.get("tracks", [])
    if len(tracks) < 2:
        return {"success": False, "error": "Need at least 2 tracks to mix"}

    print(f"PROGRESS:0/{len(tracks)}:Starting mix...", file=sys.stderr, flush=True)

    mix = None
    prev_bpm = None

    for i, track in enumerate(tracks):
        filepath = track["filepath"]
        bpm = track["bpm"]

        print(f"PROGRESS:{i+1}/{len(tracks)}:Loading {track['filename']}",
              file=sys.stderr, flush=True)

        try:
            audio = AudioSegment.from_file(filepath)
        except Exception as e:
            print(f"PROGRESS:{i+1}/{len(tracks)}:SKIP {track['filename']}: {e}",
                  file=sys.stderr, flush=True)
            continue

        # Time stretch to match previous track's BPM (gradual transition)
        if prev_bpm is not None and abs(bpm - prev_bpm) > 1:
            target = (prev_bpm + bpm) / 2  # Meet in the middle
            try:
                audio = time_stretch_audio(audio, bpm, target)
            except Exception:
                pass  # Skip stretching if it fails

        if mix is None:
            mix = audio
        else:
            print(f"PROGRESS:{i+1}/{len(tracks)}:Mixing {track['filename']}...",
                  file=sys.stderr, flush=True)

            if style == "drop_swap":
                mix = drop_swap_mix(mix, audio, track)
            else:
                # Standard crossfade: ~16 bars at current BPM
                bars_16_ms = int((60 / bpm) * 4 * 16 * 1000) if bpm > 0 else 16000
                bars_16_ms = min(bars_16_ms, 32000)  # Cap at 32 seconds
                mix = crossfade_mix(mix, audio, bars_16_ms)

        prev_bpm = bpm

    if mix is None:
        return {"success": False, "error": "No tracks could be loaded"}

    # Export
    print(f"PROGRESS:{len(tracks)}/{len(tracks)}:Exporting to {output_path}...",
          file=sys.stderr, flush=True)

    fmt = "mp3" if output_path.lower().endswith(".mp3") else "wav"
    mix.export(output_path, format=fmt, bitrate="320k")

    duration_sec = len(mix) / 1000
    return {
        "success": True,
        "output": output_path,
        "duration_sec": round(duration_sec, 2),
        "duration_formatted": f"{int(duration_sec//60)}:{int(duration_sec%60):02d}",
        "tracks_mixed": len(tracks),
        "style": style
    }


def generate_m3u(playlist_data, output_path):
    """Generate an M3U playlist file (Rekordbox compatible)."""
    tracks = playlist_data.get("tracks", [])

    lines = ["#EXTM3U"]
    for track in tracks:
        duration = int(track.get("structure", {}).get("duration_sec", 0))
        title = os.path.splitext(track["filename"])[0]
        lines.append(f"#EXTINF:{duration},{title}")
        lines.append(track["filepath"])

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    return {"success": True, "output": output_path, "tracks": len(tracks)}


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({
            "error": "Usage: dj_mixer.py <playlist.json> <output.mp3> [--style crossfade|drop_swap] [--m3u]"
        }))
        sys.exit(1)

    playlist_path = sys.argv[1]
    output_path = sys.argv[2]

    style = "crossfade"
    m3u_only = False

    for arg in sys.argv[3:]:
        if arg == "--style" and sys.argv.index(arg) + 1 < len(sys.argv):
            style = sys.argv[sys.argv.index(arg) + 1]
        if arg == "--m3u":
            m3u_only = True

    with open(playlist_path, "r") as f:
        playlist_data = json.load(f)

    if m3u_only:
        result = generate_m3u(playlist_data, output_path)
    else:
        result = create_mix(playlist_data, output_path, style)

    print(json.dumps(result, indent=2))
