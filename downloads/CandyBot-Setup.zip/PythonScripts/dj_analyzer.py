#!/usr/bin/env python3
"""
Candy-Bot DJ Engine — Audio Analyzer
Analyzes audio files for BPM, Key (Camelot), Energy, and structure.
Called from C# via subprocess. Outputs JSON to stdout.

Usage:
    python dj_analyzer.py <audio_file_path>
    python dj_analyzer.py --batch <folder_path>
"""

import sys
import os
import json
import warnings
import numpy as np

warnings.filterwarnings("ignore")

import librosa
import librosa.feature


# ═══════════════════════════════════════════
#  CAMELOT WHEEL MAPPING
# ═══════════════════════════════════════════
# Maps pitch class (0-11) to Camelot notation
# Using Krumhansl-Schmuckler key detection
MAJOR_PROFILE = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09,
                           2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
MINOR_PROFILE = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53,
                           2.54, 4.75, 3.98, 2.69, 3.34, 3.17])

# Pitch class -> Camelot notation
CAMELOT_MAJOR = {
    0: "8B",   # C major
    1: "3B",   # C#/Db major
    2: "10B",  # D major
    3: "5B",   # D#/Eb major
    4: "12B",  # E major
    5: "7B",   # F major
    6: "2B",   # F#/Gb major
    7: "9B",   # G major
    8: "4B",   # G#/Ab major
    9: "11B",  # A major
    10: "6B",  # A#/Bb major
    11: "1B",  # B major
}

CAMELOT_MINOR = {
    0: "5A",   # C minor
    1: "12A",  # C#/Db minor
    2: "7A",   # D minor
    3: "2A",   # D#/Eb minor
    4: "9A",   # E minor
    5: "4A",   # F minor
    6: "11A",  # F#/Gb minor
    7: "6A",   # G minor
    8: "1A",   # G#/Ab minor
    9: "8A",   # A minor
    10: "3A",  # A#/Bb minor
    11: "10A", # B minor
}

KEY_NAMES_MAJOR = {
    0: "C", 1: "C#", 2: "D", 3: "Eb", 4: "E", 5: "F",
    6: "F#", 7: "G", 8: "Ab", 9: "A", 10: "Bb", 11: "B"
}

KEY_NAMES_MINOR = {
    0: "Cm", 1: "C#m", 2: "Dm", 3: "Ebm", 4: "Em", 5: "Fm",
    6: "F#m", 7: "Gm", 8: "Abm", 9: "Am", 10: "Bbm", 11: "Bm"
}


def detect_key(y, sr):
    """Detect musical key using Krumhansl-Schmuckler algorithm."""
    chroma = librosa.feature.chroma_cqt(y=y, sr=sr)
    chroma_avg = np.mean(chroma, axis=1)

    # Correlate with major and minor profiles for all 12 keys
    best_corr = -1
    best_key = 0
    is_major = True

    for shift in range(12):
        major_shifted = np.roll(MAJOR_PROFILE, shift)
        minor_shifted = np.roll(MINOR_PROFILE, shift)

        corr_major = np.corrcoef(chroma_avg, major_shifted)[0, 1]
        corr_minor = np.corrcoef(chroma_avg, minor_shifted)[0, 1]

        if corr_major > best_corr:
            best_corr = corr_major
            best_key = shift
            is_major = True
        if corr_minor > best_corr:
            best_corr = corr_minor
            best_key = shift
            is_major = False

    if is_major:
        return KEY_NAMES_MAJOR[best_key], CAMELOT_MAJOR[best_key], best_corr
    else:
        return KEY_NAMES_MINOR[best_key], CAMELOT_MINOR[best_key], best_corr


def detect_bpm(y, sr):
    """Detect BPM using Librosa beat tracking."""
    tempo, _ = librosa.beat.beat_track(y=y, sr=sr)
    # tempo can be array or scalar depending on librosa version
    if hasattr(tempo, '__len__'):
        return float(tempo[0])
    return float(tempo)


def analyze_energy(y, sr):
    """Analyze energy profile using RMS and spectral features."""
    # RMS energy
    rms = librosa.feature.rms(y=y)[0]
    avg_energy = float(np.mean(rms))
    max_energy = float(np.max(rms))

    # Normalize to 0-100 scale
    energy_score = min(100, int((avg_energy / 0.15) * 100))

    # Spectral contrast (brightness/darkness)
    contrast = librosa.feature.spectral_contrast(y=y, sr=sr)
    avg_contrast = float(np.mean(contrast))

    # Energy curve (16 segments for visualization)
    segments = 16
    hop = len(rms) // segments
    energy_curve = []
    for i in range(segments):
        start = i * hop
        end = min(start + hop, len(rms))
        seg_energy = float(np.mean(rms[start:end]))
        energy_curve.append(round(seg_energy * 1000, 2))

    return {
        "score": energy_score,
        "avg_rms": round(avg_energy, 6),
        "max_rms": round(max_energy, 6),
        "spectral_contrast": round(avg_contrast, 2),
        "curve": energy_curve
    }


def detect_structure(y, sr):
    """Detect intro/outro/drop positions."""
    duration = librosa.get_duration(y=y, sr=sr)
    rms = librosa.feature.rms(y=y)[0]

    # Find where energy exceeds 30% of max (intro end)
    threshold = np.max(rms) * 0.3
    intro_end = 0
    for i, val in enumerate(rms):
        if val > threshold:
            intro_end = librosa.frames_to_time(i, sr=sr)
            break

    # Find where energy drops below 30% from end (outro start)
    outro_start = duration
    for i in range(len(rms) - 1, -1, -1):
        if rms[i] > threshold:
            outro_start = librosa.frames_to_time(i, sr=sr)
            break

    # Find peak energy position (potential drop)
    peak_frame = np.argmax(rms)
    peak_time = librosa.frames_to_time(peak_frame, sr=sr)

    return {
        "duration_sec": round(duration, 2),
        "intro_end_sec": round(float(intro_end), 2),
        "outro_start_sec": round(float(outro_start), 2),
        "peak_time_sec": round(float(peak_time), 2)
    }


def analyze_track(filepath):
    """Full analysis of a single audio track."""
    try:
        # Load audio (mono, standard sample rate)
        y, sr = librosa.load(filepath, sr=22050, mono=True)

        # Run all analyses
        bpm = detect_bpm(y, sr)
        key_name, camelot, key_confidence = detect_key(y, sr)
        energy = analyze_energy(y, sr)
        structure = detect_structure(y, sr)

        return {
            "success": True,
            "filepath": filepath,
            "filename": os.path.basename(filepath),
            "bpm": round(bpm, 1),
            "key": key_name,
            "camelot": camelot,
            "key_confidence": round(key_confidence, 3),
            "energy": energy,
            "structure": structure
        }
    except Exception as e:
        return {
            "success": False,
            "filepath": filepath,
            "filename": os.path.basename(filepath),
            "error": str(e)
        }


def analyze_folder(folder_path):
    """Analyze all audio files in a folder."""
    audio_exts = {'.mp3', '.wav', '.flac', '.m4a', '.ogg', '.aac', '.wma'}
    results = []

    files = [f for f in os.listdir(folder_path)
             if os.path.splitext(f)[1].lower() in audio_exts]

    total = len(files)
    for i, filename in enumerate(files, 1):
        filepath = os.path.join(folder_path, filename)
        # Print progress to stderr (C# can read this for progress updates)
        print(f"PROGRESS:{i}/{total}:{filename}", file=sys.stderr, flush=True)
        result = analyze_track(filepath)
        results.append(result)

    return results


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: dj_analyzer.py <file_or_folder> [--batch]"}))
        sys.exit(1)

    if sys.argv[1] == "--batch" and len(sys.argv) >= 3:
        folder = sys.argv[2]
        if not os.path.isdir(folder):
            print(json.dumps({"error": f"Not a directory: {folder}"}))
            sys.exit(1)
        results = analyze_folder(folder)
        print(json.dumps(results, indent=2))
    else:
        filepath = sys.argv[1]
        if not os.path.isfile(filepath):
            print(json.dumps({"error": f"File not found: {filepath}"}))
            sys.exit(1)
        result = analyze_track(filepath)
        print(json.dumps(result, indent=2))
